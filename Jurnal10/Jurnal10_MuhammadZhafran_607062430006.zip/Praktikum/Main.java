import java.util.List;

public class Main {

    public static void main(String[] args) {
        Graph graph = new Graph();
        graph.addVertex("Hologram" );
        graph.addVertex("Kostum");
        graph.addVertex("Pencahayaan");
        graph.addVertex("Pembuatan Panggung");
        graph.addVertex("Properti Panggung");
        graph.addVertex("Persiapan Panggung");
        graph.addVertex("Kontak Tim Lain");
        graph.addVertex("Pengepasan Kostum");

        graph.addEdge("Properti Panggung", "Kostum");
        graph.addEdge("Properti Panggung", "Persiapan Panggung");
        graph.addEdge("Persiapan Panggung", "Pembuatan Panggung");
        graph.addEdge("Hologram", "Kostum");
        graph.addEdge("Kontak Tim Lain", "Persiapan Panggung");
        graph.addEdge("Kontak Tim Lain", "Pengepasan Kostum");
        graph.addEdge("Kostum", "Pencahayaan");
        graph.addEdge("Kostum", "Pengepasan Kostum");
        graph.addEdge("Kostum", "Pembuatan Panggung");


        List<String> sortedList = graph.topologicalSort();
        if (sortedList != null) {
            System.out.println("Topological Sort: " + sortedList);
        } else {
            System.out.println("Cycle detected in the graph.");
        }
    }
}
