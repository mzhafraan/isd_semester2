package Jurnal03;

public class Node {
    Resep data;
    Node next;

    public Node(Resep data){
        this.data = data;
        this.next = null;
    }
}
