package Jurnal6.Code.Praktikum;

public class Node {
    String playerName;
    Node next;

    public Node(String playerName) {
        this.playerName = playerName;
        this.next = null;
    }
}
